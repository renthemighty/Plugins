=== First Order Free Product ===
Contributors: MetWrk - SafeHouse

Requires at least: 3.0.1
Tested up to: 5.2.2
Stable tag: 4.9

First Order Discount for Woocommerce allows admin to offer discounts to their customers on their first order with various conditions.

